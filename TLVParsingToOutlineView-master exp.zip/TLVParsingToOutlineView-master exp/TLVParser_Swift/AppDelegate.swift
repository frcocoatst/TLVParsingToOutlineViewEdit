//
//  AppDelegate.swift
//  TLVParser_Swift
//
//  Created by F. and Code Different on 22.05.18.
//  Copyleft © 2018 F. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

